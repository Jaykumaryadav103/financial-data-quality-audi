# Financial Data Quality Audit (Excel + SQL)

An end-to-end data audit project: take a messy finance transactions dataset, find every quality issue with **Excel** and **SQL**, clean it, and report the results.

## Problem
A company's transaction records (515 rows) contain duplicates, missing values, wrong totals and inconsistent labels. Before delivering the data to a client, it must be audited and cleaned.

## Tools
- MS Excel (formulas: `COUNTIF`, `IF`, `ISNUMBER/MATCH`, `SUMIFS`, `SUMPRODUCT`; filters; freeze panes)
- SQL (SQLite-compatible): `GROUP BY/HAVING`, `CASE`, `DISTINCT`, `COALESCE`-style NULL handling
- Python (pandas) only to generate the dataset and run the SQL

## Dataset (`data/raw_transactions.csv`)
Synthetic data (no real company information). Columns: `txn_id, txn_date, customer_id, customer_name, department, category, amount, tax_pct, total_amount, payment_status`.

## Data quality checks
| Check | Rule |
|---|---|
| Duplicates | `txn_id` appears more than once |
| Missing name / date | blank or NULL |
| Future dates | date after 29-Sep-2026 |
| Negative amount | `amount <= 0` |
| Total mismatch | `total_amount` != `amount * (1 + tax_pct/100)` |
| Department not standard | extra spaces / casing / unknown value |
| Invalid payment status | not Paid / Pending / Overdue |

## Results (from `excel/audit_workbook.xlsx`)
| Issue | Count |
|---|---|
| Duplicate rows (all copies) | 30 (15 extra copies) |
| Total mismatch | 31 |
| Missing customer name | 13 |
| Missing date | 11 |
| Negative amount | 8 |
| Future-dated | 7 |
| Invalid payment status | 7 |
| Department not standard | 15 (Excel, ignoring case) / 28 (SQL, exact match) |

515 raw rows -> **457 clean rows** after cleaning.

## Cleaning steps (`sql/02_clean_and_report.sql`)
1. Remove duplicate rows (`DISTINCT`)
2. Drop rows with missing name/date, future dates, non-positive amounts, invalid status
3. Standardise department names with `TRIM` + `UPPER` + `CASE`
4. Recalculate `total_amount` from `amount` and `tax_pct`

## Business output
Revenue by department and outstanding (Pending/Overdue) amount per customer, both in `sql/02_clean_and_report.sql` and in the `Audit_Summary` sheet.

## Folder structure
```
data/    raw_transactions.csv, clean_transactions.csv, audit_summary.csv
sql/     01_quality_checks.sql, 02_clean_and_report.sql
excel/   audit_workbook.xlsx  (Audit_Summary, Raw_Data with flag columns, Clean_Data, Lists)
scripts/ generate_data.py, run_audit.py, build_excel.py
```

## How to run
```bash
pip install pandas openpyxl
python scripts/generate_data.py
python scripts/run_audit.py
python scripts/build_excel.py
```

## Notes
- Excel's `MATCH` ignores case, so `MARKETING` passes the department check there while SQL's exact `NOT IN` flags it. Both are cleaned to the same standard value.
- Rows with the `N/A` status are read as NULL by pandas and are removed in cleaning.

## Key learnings
Auditing data before delivery, writing repeatable SQL checks, and building formula-driven Excel reports that update when the data changes.
